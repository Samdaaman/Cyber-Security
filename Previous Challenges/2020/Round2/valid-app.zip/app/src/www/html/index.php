<?php
  session_start();
  $allowed_hosts = '/etc/allowed_hosts';
  $token = $_SERVER["HTTP_X_TOKEN"];
  if (! $token || $token != $_SESSION["TOKEN"]) {
    http_response_code(401);
    exit;
  }
  $json = file_get_contents("php://input");
  $links = json_decode($json);
  for ($i = 0; true; $i++) {
    if (! $links->$i) { break; }
    $is_bad = pclose(popen("awk -v link='" . $links->$i .
      "' 'BEGIN {rc=1} (link ~ $0) {rc=0; exit} END {exit rc}' " .
      $allowed_hosts, "r"));
    if ($is_bad) {
      echo "false";
      exit;
    }
  }
  echo "true";
?>
