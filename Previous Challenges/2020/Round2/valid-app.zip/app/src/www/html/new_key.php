<?php
  session_start();
  session_unset();
  session_destroy();
  session_start();
  session_regenerate_id();
  http_response_code(204);
  $_SESSION["TOKEN"] = bin2hex(openssl_random_pseudo_bytes(16));
  // this request may be coming from anyone on the LAN, so to ensure only
  // the admin server process can get the token, we send it out of band to
  // it
  $url = 'http://admin/api/token';
  $options = array(
    'http' => array(
      'header'  => "X-TOKEN: " . $_SESSION["TOKEN"] . "\r\n",
      'method'  => 'GET',
    ),
  );
  $context  = stream_context_create($options);
  $result = file_get_contents($url, false, $context);
  file_put_contents('php://stderr', "New: " . $_SESSION["TOKEN"] . "\n");
  file_put_contents('php://stderr', "SESSID: " . session_id() . "\n");
?>
