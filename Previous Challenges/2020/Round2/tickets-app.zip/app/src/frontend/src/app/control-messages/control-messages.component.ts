import { Component, Input } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { ValidationService } from '@app/_services';

@Component({
  selector: 'control-messages',
  templateUrl: './control-messages.component.html',
  styleUrls: ['./control-messages.component.css']
})
export class ControlMessagesComponent {
  @Input() control: FormControl;
  constructor() {}

  get errorMessages() {
    let errors = [];
    for (let propertyName in this.control.errors) {
      if (
        this.control.errors.hasOwnProperty(propertyName) &&
        this.control.touched
      ) {
        errors.push(ValidationService.getValidatorErrorMessage(
          propertyName,
          this.control.errors[propertyName]
        ));
      }
    }
    return errors;
  }
}
