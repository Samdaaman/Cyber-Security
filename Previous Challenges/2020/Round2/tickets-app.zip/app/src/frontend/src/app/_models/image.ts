import { SafeResourceUrl } from '@angular/platform-browser';

export interface Image {
  filename: string;
  blob: string;
  src: SafeResourceUrl;
}
