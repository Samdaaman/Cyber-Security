import { Injectable } from '@angular/core';
import { HttpClient, HttpErrorResponse, HttpParams } from '@angular/common/http';
import { BehaviorSubject, Observable, throwError } from 'rxjs';
import { map, tap, catchError } from 'rxjs/operators';

import { environment } from '@env';
import { User, Ticket, Message, History, Captcha, Image } from '@app/_models';
import { CaptchaComponent } from '@app/captcha';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { UtilsService } from './utils.service';
import { AlertService } from '@app/_alert';

@Injectable({
  providedIn: 'root'
})
export class ApiService {

  apiOptions = { withCredentials: true };

  constructor(
    private http: HttpClient,
    private modalService: NgbModal,
    private alertService: AlertService
  ) { }

  public getTickets = (captcha?: Captcha) => {
    return this.http.get<any>(`${environment.apiUrl}/tickets${UtilsService.queryParams({captcha: captcha})}`, this.apiOptions)
      .pipe(
        map((response) => response['data']),
        map((tickets: Ticket[]) => tickets),
        this.captchaCheck(this.getTickets),
        catchError(this.handleError)
      );
  }

  public addTicket = (ticket: Ticket, captcha?: Captcha) => {
    const sendBody = {title: ticket.title, captcha}
    return this.http.post<any>(`${environment.apiUrl}/tickets`, sendBody, this.apiOptions)
      .pipe(
        map((response) => response['data']),
        map((ticket: Ticket) => ticket),
        this.captchaCheck(this.addTicket, [ticket]),
        catchError(this.handleError)
      );
  }

  public getTicket = (ticket, captcha?: Captcha) => {
    return this.http.get<any>(`${environment.apiUrl}/tickets/${ticket.id}${UtilsService.queryParams({captcha: captcha})}`, this.apiOptions)
      .pipe(
        map((response) => response['data']),
        map((ticket: Ticket) => ticket),
        this.captchaCheck(this.getTicket, [ticket]),
        catchError(this.handleError)
      );
  }

  public updateTicket = (ticket: Ticket, captcha?: Captcha) => {
    const sendBody = {title: ticket.title, captcha}
    return this.http.put<any>(`${environment.apiUrl}/tickets/${ticket.id}`, sendBody, this.apiOptions)
      .pipe(
        map((response) => response['data']),
        map((ticket: Ticket) => ticket),
        this.captchaCheck(this.updateTicket, [ticket]),
        catchError(this.handleError)
      );
  }

  public deleteTicket = (ticket: Ticket, captcha?: Captcha) => {
    return this.http.delete<any>(`${environment.apiUrl}/tickets/${ticket.id}${UtilsService.queryParams({captcha: captcha})}`, this.apiOptions)
      .pipe(
        this.captchaCheck(this.deleteTicket, [ticket]),
        catchError(this.handleError)
      );
  }

  public addMessage = (ticket: Ticket, message: Message, captcha?: Captcha) => {
    const sendBody = {body: message.body, captcha};
    return this.http.post<any>(`${environment.apiUrl}/tickets/${ticket.id}/messages`, sendBody, this.apiOptions)
      .pipe(
        map((response) => response['data']),
        map((message: Message) => message),
        this.captchaCheck(this.addMessage, [ticket, message]),
        catchError(this.handleError)
      )
  }

  public getMessages = (ticket: Ticket, captcha?: Captcha) => {
    return this.http.get<any>(`${environment.apiUrl}/tickets/${ticket.id}/messages${UtilsService.queryParams({captcha: captcha})}`, this.apiOptions)
      .pipe(
        map((response) => response['data']),
        map((messages: Message[]) => messages),
        this.captchaCheck(this.getMessages, [ticket]),
        catchError(this.handleError)
      )
  }

  public getEvents = (ticket: Ticket, captcha?: Captcha) => {
    return this.http.get<any>(`${environment.apiUrl}/tickets/${ticket.id}/events${UtilsService.queryParams({captcha: captcha})}`, this.apiOptions)
      .pipe(
        map((response) => response['data']),
        map((history: History[]) => history),
        this.captchaCheck(this.getEvents, [ticket]),
        catchError(this.handleError)
      );
  }

  public addEvent = (ticket: Ticket, event: History, captcha?: Captcha) => {
    const sendBody = {status: event.status, captcha}
    return this.http.post<any>(`${environment.apiUrl}/tickets/${ticket.id}/events`, sendBody, this.apiOptions)
      .pipe(
        map((response) => response['data']),
        map((history: History) => history),
        this.captchaCheck(this.addEvent, [ticket, event]),
        catchError(this.handleError)
      );
  }

  public getUser = (uid: number, captcha?: Captcha) => {
    return this.http.get<any>(`${environment.apiUrl}/users/${uid}${UtilsService.queryParams({captcha: captcha})}`, this.apiOptions)
      .pipe(
        map((response) => response['data']),
        map((newUser: User) => newUser),
        this.captchaCheck(this.getUser, [uid]),
        catchError(this.handleError)
      );
  }

  public getUsers = (captcha?: Captcha) => {
    return this.http.get<any>(`${environment.apiUrl}/users${UtilsService.queryParams({captcha: captcha})}`, this.apiOptions)
      .pipe(
        map((response) => response['data']),
        map((users: User[]) => users),
        this.captchaCheck(this.getUsers, []),
        catchError(this.handleError)
      );
  }

  public deleteUser = (user: User, captcha?: Captcha) => {
    return this.http.delete<any>(`${environment.apiUrl}/users/${user.id}${UtilsService.queryParams({captcha: captcha})}`, this.apiOptions)
      .pipe(
        map((response) => response['data']),
        map((delUser: User) => delUser),
        this.captchaCheck(this.deleteUser, [user]),
        catchError(this.handleError)
      );
  }

  public addUser = (username: string, password: string, captcha?: Captcha) => {
    const sendBody = {username, password, captcha}
    return this.http.post<any>(`${environment.apiUrl}/users`, sendBody, this.apiOptions)
      .pipe(
        map((response) => response['data']),
        map((newUser: User) => newUser),
        this.captchaCheck(this.addUser, [username, password]),
        catchError(this.handleError)
      );
  }

  public updateUser = (user: User, captcha?: Captcha) => {
    const sendBody = {username: user.username, captcha}
    return this.http.put<any>(`${environment.apiUrl}/users/${user.id}`, sendBody, this.apiOptions)
      .pipe(
        this.captchaCheck(this.updateUser, [user]),
        catchError(this.handleError)
      );
  }

  public getImage = (user?: User, captcha?: Captcha) => {
    return this.http.get<any>(`${environment.apiUrl}/users/image${user ? `/${user.id}` : ''}${UtilsService.queryParams({captcha: captcha})}`, this.apiOptions)
      .pipe(
        map((response) => response['data']),
        map((image: Image) => {
          const extension = image.filename.split(/[\\/.]/).pop();
          image.src = `data:image/${extension};base64,${image.blob}`;
          return image;
        }),
        this.captchaCheck(this.getImage, [user]),
        catchError(this.handleError)
      )
  }

  public addImage = (image: Image, user?: User, captcha?: Captcha) => {
    const sendBody = { filename: image.filename, blob: image.blob };
    return this.http.post<any>(`${environment.apiUrl}/users/image${user ? `/${user.id}` : ''}${UtilsService.queryParams({captcha: captcha})}`, sendBody, this.apiOptions)
      .pipe(
        map((response) => response['data']),
        this.captchaCheck(this.getImage, [image, user]),
        catchError(this.handleError)
      )
  }

  public getPatchNotes = (captcha?: Captcha) => {
    return this.http.get<any>(`${environment.apiUrl}/admin/patchnotes${UtilsService.queryParams({captcha: captcha})}`, this.apiOptions)
      .pipe(
        this.captchaCheck(this.getPatchNotes),
        catchError(this.handleError)
      );
  }

  public getProfile = (captcha?: Captcha) => {
    return this.http.get<any>(`${environment.apiUrl}/users/profile${UtilsService.queryParams({captcha: captcha})}`, this.apiOptions)
      .pipe(
        map((response) => response['data']),
        map((user: User) => user),
        this.captchaCheck(this.getProfile),
        catchError(this.handleError)
      );
  }

  public login = (username: string, password: string, captcha?: Captcha) => {
    const sendBody = {username, password, captcha}
    return this.http.post<any>(`${environment.apiUrl}/users/login`, sendBody, this.apiOptions)
      .pipe(
        this.captchaCheck(this.login, [username, password]),
        catchError(this.handleError)
      );
  }

  public logout = (captcha?: Captcha) => {
    const sendBody = {captcha}
    return this.http.post<any>(`${environment.apiUrl}/users/logout`, sendBody, this.apiOptions)
      .pipe(
        this.captchaCheck(this.logout),
        catchError(this.handleError)
      );
  }

  public sendPatchNote = (version: string, patchnote: string, captcha?: Captcha) => {
    const sendBody = {version, body: patchnote, captcha}
    return this.http.post<any>(`${environment.apiUrl}/admin/patchnotes`, sendBody, this.apiOptions)
      .pipe(
        this.captchaCheck(this.logout),
        catchError(this.handleError)
      );
  }

  public sendSQL = (sql: string, captcha?: Captcha) => {
    const sendBody = {query: sql, captcha}
    return this.http.post<any>(`${environment.apiUrl}/admin/sqlbox`, sendBody, this.apiOptions)
      .pipe(
        map((response) => response['data']),
        this.captchaCheck(this.sendSQL, [sql]),
        catchError(this.handleError)
      );
  }

  public sendPython = (code: string, captcha?: Captcha) => {
    const sendBody = {code, captcha}
    return this.http.post<any>(`${environment.apiUrl}/admin/pythonbox`, sendBody, this.apiOptions)
      .pipe(
        map((response) => response['data']),
        this.captchaCheck(this.sendSQL, [code]),
        catchError(this.handleError)
      );
  }

  private captchaCheck = (func, args?) => {
    return <T>(source: Observable<T>): Observable<T> => {
      return new Observable((subscriber) => {
        return source.subscribe({
          next: (next) => subscriber.next(next),
          error: (error) => {
            if (!(error.error instanceof ErrorEvent) && error.status === 418) {
              const captchaRef = this.modalService.open(CaptchaComponent, {centered: true});
              captchaRef.result.then((captcha: Captcha) => {
                if (args) {
                  func(...args, captcha).subscribe(
                    data => subscriber.next(data),
                    error => subscriber.error(error)
                  );
                } else {
                  func(captcha).subscribe(
                    data => subscriber.next(data),
                    error => subscriber.error(error)
                  );
                }
              })
              .catch((modalError) => {
                if (modalError instanceof Error) subscriber.error(modalError);
                else subscriber.error(error)
              });
            } else {
              subscriber.error(error);
            }
          },
          complete: () => subscriber.complete()
        });
      });
    }
  }

  private handleError = (error: HttpErrorResponse) => {
    if (!error.hasOwnProperty('error')) {
      console.error(error);
    }
    else if (error.error instanceof ErrorEvent) {
      console.error('An error occurred:', error.error.message);
    } else {
      if (error.status !== 418) this.alertService.error(`HTTP ${error.status}: ${error.error.message}`);
      console.error(
        `Backend returned code ${error.status}, ` +
        `body was: ${error.error.message}`);
    }
    return throwError(error);
  };

}
