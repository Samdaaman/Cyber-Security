import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { catchError, map } from 'rxjs/operators';

import { ApiService } from './api.service';
import { User } from '@app/_models/user';

@Injectable({
  providedIn: 'root'
})
export class AuthenticationService {
  private currentUserSubject: BehaviorSubject<User>;
  public currentUser: Observable<User>;

  constructor(
    private http: HttpClient,
    private apiService: ApiService
  ) {
    this.currentUserSubject = new BehaviorSubject<User>(JSON.parse(localStorage.getItem('currentUser')));
    this.currentUser = this.currentUserSubject.asObservable();
    if (this.currentUserValue) {
      this.apiService.getProfile()
        .subscribe(
          data => {},
          (error) => {
            this.currentUserSubject.next(null);
            localStorage.removeItem('currentUser');
          }
        )
    }
  }

  public get currentUserValue(): User {
    return this.currentUserSubject.value;
  }

  login(username: string, password: string) {
    return this.apiService.login(username, password)
      .pipe(map(response => {
        localStorage.setItem('currentUser', JSON.stringify(response['data']));
        this.currentUserSubject.next(response['data']);
        return response['data'];
      }));
    }

  logout() {
    return this.apiService.logout()
      .pipe(map(() => {
        localStorage.removeItem('currentUser');
        this.currentUserSubject.next(null);
        return null;
      }));
  }

  refresh() {
    return this.apiService.getUser(this.currentUserValue.id)
      .pipe(
        map(user => {
          localStorage.setItem('currentUser', JSON.stringify(user));
          this.currentUserSubject.next(user);
          return user;
        })
      )
  }

}
