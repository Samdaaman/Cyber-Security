import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { DashboardComponent }   from './dashboard';
import { AboutComponent }   from './about';
import { AdminComponent }   from './admin';
import { LoginComponent }   from './login';
import { SignupComponent }   from './signup';
import { UserComponent }   from './user';
import { AuthGuard, AdminGuard } from './_helpers'

const routes: Routes = [
  { path: '', redirectTo: 'dashboard/', pathMatch: 'full' },
  { path: 'dashboard', redirectTo: 'dashboard/', pathMatch: 'full' },
  { path: 'dashboard/:id', component: DashboardComponent, canActivate: [ AuthGuard ], runGuardsAndResolvers: 'always'},
  { path: 'admin', component: AdminComponent, canActivate: [ AuthGuard, AdminGuard ], runGuardsAndResolvers: 'always'},
  { path: 'about', component: AboutComponent },
  { path: 'login', component: LoginComponent },
  { path: 'signup', component: SignupComponent },
  { path: 'user/:id', component: UserComponent, canActivate: [ AuthGuard ], runGuardsAndResolvers: 'always'}
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, {
      useHash: true,
      onSameUrlNavigation: 'reload'
    })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
