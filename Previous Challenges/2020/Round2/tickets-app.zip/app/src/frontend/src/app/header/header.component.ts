import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd, ActivatedRoute } from '@angular/router';
import { filter, first } from 'rxjs/operators';

import { AuthenticationService } from '@app/_services';
import { User } from '@app/_models';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  user: User;
  route: string;

  constructor(
    private authenticationService: AuthenticationService,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) {

   }

  ngOnInit(): void {
    console.log(this.router, this.activatedRoute);
    this.route = document.location.hash.substring(1);

    this.router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event: NavigationEnd) => {
      this.route = event.urlAfterRedirects;
    });

    this.authenticationService.currentUser.subscribe((user) => {
      this.user = user;
    });

  }

  loginRedirect(): void {
    if (this.route.startsWith('/login')) return;
    this.router.navigate(['/login'], { queryParams: { r: this.route } });
  }

  logout(): void {
    this.authenticationService.logout()
      .subscribe(
        data => {
          this.router.navigate([this.route]);
        },
        error => {
        }
      )
  }
}
