import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators';

import { ApiService } from './api.service';
import { PatchNote } from '@app/_models';

@Injectable({
  providedIn: 'root'
})
export class PatchNotesService {
  private patchNotesSubject: BehaviorSubject<PatchNote[]>;
  public patchNotes: Observable<PatchNote[]>;

  constructor(
    private http: HttpClient,
    private apiService: ApiService
  ) {
    this.patchNotesSubject = new BehaviorSubject<PatchNote[]>([]);
    this.patchNotes = this.patchNotesSubject.asObservable();
  }

  public get getPatchNotes(): PatchNote[] {
    return this.patchNotesSubject.value;
  }

  loadPatchNotes() {
    return this.apiService.getPatchNotes()
      .pipe(map(response => {
        this.patchNotesSubject.next(response['data']);
        return response['data'];
      }));
    }
}
