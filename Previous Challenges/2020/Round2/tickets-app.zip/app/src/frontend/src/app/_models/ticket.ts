import { User } from './user';

export interface History {
  id: number;
  user: User;
  changeTime: number;
  status: string;
  eventType: string;
}

export interface Message {
  id: number;
  user: User;
  sentTime: number;
  body: string;
}

export interface Ticket {
  id: number;
  title: string;
  owner: User;
  history: History[];
  messages: Message[];
}
