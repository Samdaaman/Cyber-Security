export interface Captcha {
  q: string;
  a: string;
}
