export class ValidationService {

  static getValidatorErrorMessage(validatorName: string, validatorValue?: any) {
    let config = {
      required: 'Required',
      passwordShort: 'Password must be between 6 and 100 characters',
      passwordComplexity: 'Password must contain 3 out of 4 of lower case, upper case, symbols, or numbers',
      passwordMatch: 'Passwords do not match',
      minlength: `Minimum length ${validatorValue.requiredLength}`,
      captchaSymbol: 'The captcha must contain at least one +, -, *, or / symbol'
    };
    return config[validatorName];
  }

  static passwordValidator(control) {
    // {6,100}           - Assert password is between 6 and 100 characters
    // (?=.*[0-9])       - Assert a string has at least one number
    let strength = [];
    let errors = {};
    if (!control.value.match(/^.{6,100}$/)) errors['passwordShort'] = true; // length shortcut
    if (control.value.match(/^(?=.*[a-z])/)) strength.push('l');
    if (control.value.match(/^(?=.*[A-Z])/)) strength.push('u');
    if (control.value.match(/^(?=.*[0-9])/)) strength.push('n');
    if (control.value.match(/^(?=.*[ `~!@#$%^&*()_+\-={}|[\]\\:";'<>?,.\/])/)) strength.push('s');
    if (strength.length < 3) errors['passwordComplexity'] = true; // must match 3/4 of the groups
    return Object.keys(errors).length ? errors : null;
  }

  static passwordMatchValidator(group) {
    let pass = group.get('password');
    let passConf = group.get('passwordConf');
    if (pass.value !== passConf.value) {
      if (passConf.errors) passConf.errors['passwordMatch'] = true;
      else passConf.errors = { passwordMatch: true };
      return { passwordMatch: true };
    }
  }

  static captchaValidator(control) {
    if (!control.value.match(/^.*[\-+*/]/)) return { captchaSymbol: true };
    return null;
  }

}
