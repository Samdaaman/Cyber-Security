import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder }  from '@angular/forms';

import { ApiService } from '@app/_services';
import { User } from '@app/_models';

class Tool {
  label: string;
  name: string;
  constructor(name: string, label: string) {
    this.label = label;
    this.name = name;
  }
}

class SQLOutput {
  header: string[] = [];
  rows: any[][] = [];

  constructor(rows) {
    if (!rows.length) return;
    for (let key in rows[0]) {
      if (rows[0].hasOwnProperty(key)) this.header.push(key);
    }
    this.rows = rows.map((row) => this.header.map((key) => {
      const value = row[key];
      if (typeof value === 'object') return JSON.stringify(value);
      return value;
    }));
  }
}

interface PythonOutput {
  stdout: string;
  stderr: string;
}

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  tools: Tool[];
  currentTool: Tool;

  patchForm: FormGroup;
  sqlForm: FormGroup;
  pythonForm: FormGroup;
  submitted: boolean = false;
  error: string = '';
  sqlOutput: SQLOutput | null = null;
  pythonOutput: PythonOutput | null = null;
  loading: boolean = false;
  loadingPage: boolean = false;

  users: User[];
  deleteLoading: User | null;

  constructor(
    private formBuilder: FormBuilder,
    private apiService: ApiService
  ) { }

  ngOnInit(): void {
    this.tools = [
      new Tool("patches", "Patches"),
      new Tool("sqlbox", "SQL Query"),
      new Tool("pythonbox", "Python Code"),
      new Tool("userlist", "User List")
    ];

    this.patchForm = this.formBuilder.group({
      version: ['', Validators.required],
      patchnote: ['', Validators.required]
    });

    this.sqlForm = this.formBuilder.group({
      sql: ['', Validators.required]
    });

    this.pythonForm = this.formBuilder.group({
      code: ['', Validators.required]
    });
  }

  selectTool(tool: Tool) {
    this.currentTool = tool;
    this.submitted = false;
    this.loading = false;
    this.error = '';
    if (this.currentTool.name === 'userlist') this.getUsers();
  }

  sendPatch() {
    this.submitted = true;
    if (this.patchForm.invalid) return;

    this.loading = true;
    this.apiService.sendPatchNote(this.patchForm.controls.version.value, this.patchForm.controls.patchnote.value)
      .subscribe(
        data => {
          this.patchForm.controls.version.setValue('');
          this.patchForm.controls.patchnote.setValue('');
          this.submitted = false;
          this.loading = false;
        },
        error => {
          this.error = error.error.message;
          this.loading = false;
        }
      )
  }

  sendSQL() {
    this.submitted = true;
    if (this.sqlForm.invalid) return;

    this.loading = true;
    this.apiService.sendSQL(this.sqlForm.controls.sql.value)
      .subscribe(
        data => {
          this.sqlOutput = new SQLOutput(data['rows']);
          this.loading = false;
          this.error = "";
        },
        error => {
          this.sqlOutput = null;
          this.error = error.error.message;
          this.loading = false;
        }
      )
  }

  sendPython() {
    this.submitted = true;
    if (this.pythonForm.invalid) return;

    this.loading = true;
    this.apiService.sendPython(this.pythonForm.controls.code.value)
      .subscribe(
        data => {
          this.pythonOutput = data;
          this.loading = false;
          this.error = "";
        },
        error => {
          this.pythonOutput = null;
          this.error = error.error.message;
          this.loading = false;
        }
      )
  }

  getImage(user) {
    user.loading = true;
    this.apiService.getImage(user)
      .subscribe(
        image => {
          user.image = image;
          user.loading = false;
        },
        error => {
          user.loading = false;
        }
      )
  }

  getUsers() {
    this.loadingPage = true;

    this.apiService.getUsers()
      .subscribe(
        data => {
          this.loadingPage = false;
          this.users = data;
          this.users.map((user) => this.getImage(user));
        },
        error => {
          this.loadingPage = false;
        }
      )
  }

  deleteUser(user: User) {
    this.deleteLoading = user;

    this.apiService.deleteUser(user)
      .subscribe(
        data => {
          this.deleteLoading = null;
          this.getUsers();
        },
        error => {
          this.deleteLoading = null;
        }
      )
  }

}
