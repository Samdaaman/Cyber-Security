export interface PatchNote {
  id: number;
  version: string;
  body: string;
}
