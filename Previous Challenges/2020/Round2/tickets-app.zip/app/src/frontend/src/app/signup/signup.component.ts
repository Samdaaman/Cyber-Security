import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { FormGroup, FormControl, FormsModule, ReactiveFormsModule, Validators, FormBuilder }  from '@angular/forms';
import { first } from 'rxjs/operators';

import { AuthenticationService, ApiService, ValidationService } from '@app/_services';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {

  signupForm: FormGroup;
  loading = false;
  submitted = false;
  redirect: string;
  error = '';


  constructor(
    private formBuilder: FormBuilder,
    private route: ActivatedRoute,
    private router: Router,
    private authenticationService: AuthenticationService,
    private apiService: ApiService
  ) { }

  ngOnInit(): void {

    this.signupForm = this.formBuilder.group({
            username: ['', Validators.required],
            password: ['', [Validators.required, ValidationService.passwordValidator]],
            passwordConf: ['', Validators.required]
        }, {validator: ValidationService.passwordMatchValidator});


    this.route.queryParams.subscribe(params => {
      this.redirect = params.hasOwnProperty('r') ? decodeURI(params.r) : '/';
    });

    this.authenticationService.currentUser.subscribe((user) => {
      if (user) {
        if (this.redirect.startsWith('/')) {
          this.router.navigate([this.redirect]);
        } else {
          window.location.href = this.redirect;
        }
      }
    });

  }

  get form() { return this.signupForm.controls; }


  onSubmit(): void {
    this.submitted = true;

    if (this.signupForm.invalid) return;

    this.loading = true;
    this.apiService.addUser(this.form.username.value, this.form.password.value)
      .pipe(first())
      .subscribe(
        data => {
          this.authenticationService.login(this.form.username.value, this.form.password.value)
            .pipe(first())
            .subscribe(
              data => {
                this.loading = false;
              },
              error => {
                this.error = error.error.message;
                this.loading = false;
              }
            )
        },
        error => {
          this.error = error.error.message;
          this.loading = false;
        }
      )
  }

}
