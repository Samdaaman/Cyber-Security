import { Component, OnInit } from '@angular/core';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { FormGroup, FormControl, FormsModule, ReactiveFormsModule, Validators, FormBuilder }  from '@angular/forms';
import { Subscription } from 'rxjs';

import { Captcha } from '@app/_models/captcha';
import { ValidationService } from '@app/_services/validation.service';


@Component({
  selector: 'app-captcha',
  templateUrl: './captcha.component.html',
  styleUrls: ['./captcha.component.css']
})
export class CaptchaComponent implements OnInit {

  captcha: Captcha;

  submitted: boolean = false;

  captchaForm: FormGroup;
  captchaFormSubscription: Subscription;

  constructor(
    public activeModal: NgbActiveModal,
    private formBuilder: FormBuilder
  ) {  }

  ngOnInit(): void {
    this.captcha = {
      q: Math.floor((Math.random() * 1000) + 1).toString(),
      a: ""
    };

    this.captchaForm = this.formBuilder.group({
            answer: ['', [Validators.required, ValidationService.captchaValidator]]
        });

    this.captchaFormSubscription = this.captchaForm.valueChanges.subscribe((updatedValue) => {
      if (updatedValue.answer) this.captcha.a = updatedValue.answer;
    });
  }

  ngOnDestroy(): void {
    this.captchaFormSubscription.unsubscribe();
  }

  get cf() { return this.captchaForm.controls; }

  onSubmit() {
    this.submitted = true;
    if (this.captchaForm.invalid) return;
    this.activeModal.close(this.captcha);
  }

}
