import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { filter, first } from 'rxjs/operators';
import { Subscription } from 'rxjs';
import { Location } from '@angular/common';

import { ApiService } from '@app/_services';
import { Ticket } from '@app/_models';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  tickets: Ticket[] = [];
  selectedTicket: Ticket;
  loading = {
    tickets: true,
    newTicket: false
  };


  private routerSubscription: Subscription;

  constructor(
    private apiService: ApiService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private location: Location
  ) { }

  ngOnInit(): void {
    this.getTickets();

    this.routerSubscription = this.router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event: NavigationEnd) => {
      this.selectTicket();
    });
  }

  ngOnDestroy(): void {
    this.routerSubscription.unsubscribe();
  }

  getTickets(): void {
    this.apiService.getTickets()
      .subscribe(tickets => {
        this.tickets = tickets.sort((t1, t2) => t1.id - t2.id);
        this.loading.tickets = false;
        this.selectTicket();
      });
  }

  selectTicket(ticket: Ticket | undefined = undefined): void {
    if (ticket === undefined) {
      const id = +this.activatedRoute.snapshot.paramMap.get('id');
      const selectedTicket = this.tickets.filter((ticket) => ticket.id === id);
      if (selectedTicket.length === 1) ticket = selectedTicket[0];
      else return;
    }
    this.selectedTicket = ticket;
  }

  deleteTicket(event) {
    let index = this.tickets.map(ticket => ticket.id).indexOf(this.selectedTicket.id);
    if (index >= 0) this.tickets.splice(index, 1);
    if (index === this.tickets.length) index--;
    if (index >= 0) this.selectTicket(this.tickets[index]);
    else {
      this.selectedTicket = undefined;
      this.router.navigate(['/dashboard']);
    }
  }

  newTicket() {
    let newTicket: Ticket = {
      id: null,
      title: "New Ticket",
      owner: null,
      history: null,
      messages: null
    }
    this.loading.newTicket = true;
    this.apiService.addTicket(newTicket)
      .subscribe(
        data => {
          this.loading.newTicket = false;
          Object.assign(newTicket, data)
          this.tickets.push(newTicket);
          this.selectTicket(newTicket);
        },
        error => {
          this.loading.newTicket = false;
        }
      )
  }

}
