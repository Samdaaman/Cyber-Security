export * from './captcha.component';
