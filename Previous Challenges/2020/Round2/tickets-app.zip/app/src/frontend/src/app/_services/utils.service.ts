export class UtilsService {

  static queryParams(args) {
    let result = [];
    const flatObject = UtilsService.flattenObject(args);
    for (let key in flatObject) {
      if (!flatObject.hasOwnProperty(key)) continue;
      const keyList = key.split('\u0000');
      result.push(`${encodeURIComponent(keyList[0])}${keyList.slice(1).map(val => `[${encodeURIComponent(val)}]`).join('')}=${encodeURIComponent(flatObject[key])}`);
    }
    let output = "";
    if (result.length) output = "?" + result.join("&");
    return output;
  }

  static flattenObject(ob) {
      let toReturn = {};
      for (var i in ob) {
          if (!ob.hasOwnProperty(i)) continue;
          if (ob[i] === null || ob[i] === undefined) continue;
          if ((typeof ob[i]) == 'object') {
              const flatObject = UtilsService.flattenObject(ob[i]);
              for (var x in flatObject) {
                  if (!flatObject.hasOwnProperty(x)) continue;
                  toReturn[i + '\u0000' + x] = flatObject[x];
              }
          } else {
              toReturn[i] = ob[i];
          }
      }
      return toReturn;
  }

}
