import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder }  from '@angular/forms';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Subscription } from 'rxjs';
import { DatePipe } from '@angular/common';


import { ApiService, AuthenticationService } from '@app/_services';
import { Ticket, User, Message, History } from '@app/_models';

@Component({
  selector: 'app-ticket',
  templateUrl: './ticket.component.html',
  styleUrls: ['./ticket.component.css']
})
export class TicketComponent implements OnInit {

  ticket: Ticket;
  editing: boolean = false;
  newTicket: boolean = false;
  loading = {
    ticket: false,
    saving: false,
    deleting: false,
    sendingMessage: false,
    sendingHistory: false
  }
  activeTab: string = "messages-tab";
  currentStatus: string = "";

  ticketForm: FormGroup;
  ticketFormSubscription: Subscription;
  messageForm: FormGroup;

  messagesRefresh;
  historyRefresh;


  @Output()
  deleteEvent = new EventEmitter<Ticket>();

  @Input()
  public set selectedTicket(ticket: Ticket) {
    this.ticket = ticket;
    this.editing = false;
    this.stopMessagesRefresh();
    this.stopHistoryRefresh();
    if (ticket) {
      this.getTicket(ticket);
    }
  };

  constructor(
    private apiService: ApiService,
    private formBuilder: FormBuilder,
    private authenticationService: AuthenticationService,
    private datePipe: DatePipe
  ) { }

  ngOnInit(): void {
    this.ticketForm = this.formBuilder.group({
            title: ['', Validators.required]
        });

    this.messageForm = this.formBuilder.group({
            message: ['', Validators.required]
        });

    this.ticketFormSubscription = this.ticketForm.valueChanges.subscribe((updatedValue) => {
      Object.assign(this.ticket, updatedValue);
    });

  }

  ngOnDestroy(): void {
    this.ticketFormSubscription.unsubscribe();
    this.stopMessagesRefresh();
    this.stopHistoryRefresh();
  }

  public get tf() {
    return this.ticketForm.controls;
  }

  public get mf() {
    return this.messageForm.controls;
  }

  getTicket(ticket: Ticket): void {
    this.loading.ticket = true;
    this.apiService.getTicket(ticket)
      .subscribe(newTicket => {
        if (this.ticket.id === newTicket.id) Object.assign(this.ticket, newTicket);
        this.updateForm();
        this.updateStatus();
        this.startMessageRefresh();
        this.startHistoryRefresh();
        this.loading.ticket = false;

      },
      error => {
        this.getTicket(ticket);
      }
    );
  }

  updateForm(): void {
    this.ticketForm.setValue({title: this.ticket.title});
  }

  deleteTicket(): void {
    if (this.ticket.id) {
      this.loading.deleting = true;
      this.apiService.deleteTicket(this.ticket)
        .subscribe(
          data => {
            this.loading.deleting = false;
            this.deleteEvent.emit(this.ticket);
          },
          error => {
            this.loading.deleting = false;
          }
        )
    } else {
      this.deleteEvent.emit(this.ticket);
    }
  }

  changeTab(event) {
    this.activeTab = event.target.id;
    if (this.activeTab === 'messages-tab') {
      this.stopHistoryRefresh();
      this.getMessages();
    } else {
      this.stopMessagesRefresh();
      this.getHistory();
    }
  }

  updateStatus(): void {
    this.currentStatus = this.ticket.history[this.ticket.history.length - 1].status;
  }

  markAsToggle(): void {
    this.loading.sendingHistory = true;
    const history: History = {
      id: null,
      user: this.authenticationService.currentUserValue,
      changeTime: Date.now(),
      status: this.currentStatus === 'open' ? 'closed' : 'open',
      eventType: 'statusChange'
    }

    this.apiService.addEvent(this.ticket, history)
      .subscribe(
        data => {
          this.getHistory();
          this.loading.sendingHistory = false;
        },
        error => {
          this.loading.sendingHistory = false;
        }
      )
  }

  editTicket(): void {
    this.editing = true;
  }

  saveTicket(): void {
    this.editing = false;

    if (this.ticketForm.invalid) return;

    this.loading.saving = true;
    this.apiService.updateTicket(this.ticket)
      .subscribe(
        data => {
          this.getHistory();
          this.loading.saving = false;
        },
        error => {
          this.loading.saving = false;
        }
      )
  }

  sendMessage(): void {
    if (this.messageForm.invalid) return;

    this.loading.sendingMessage = true;

    const message: Message = {
      id: null,
      user: this.authenticationService.currentUserValue,
      sentTime: Date.now(),
      body: this.mf.message.value
    }
    let index = this.ticket.messages.length

    this.ticket.messages.push(message);
    this.mf.message.setValue("");

    this.apiService.addMessage(this.ticket, message)
      .subscribe(
        data => {
          Object.assign(this.ticket.messages[index], data);
          this.loading.sendingMessage = false;
        },
        error => {
          this.mf.message.setValue(this.ticket.messages[index].body);
          this.ticket.messages.splice(index, 1);
          this.loading.sendingMessage = false;
        }
      )
  }

  getMessages(): void {
    this.messagesRefresh = null;
    if (this.ticket) {
      this.apiService.getMessages(this.ticket)
        .subscribe(
          data => {
            this.ticket.messages = data;
            this.startMessageRefresh();
          },
          error => {
            this.startMessageRefresh();
          }
        )
    }
  }

  getHistory(): void {
    if (this.ticket) {
      this.apiService.getEvents(this.ticket)
        .subscribe(
          data => {
            this.ticket.history = data;
            this.updateStatus();
            this.startHistoryRefresh();
          },
          error => {
            this.startHistoryRefresh();
          }
        )
    }
  }

  isItemMine(item: Message | History): boolean {
    return item.user.id === this.authenticationService.currentUserValue.id;
  }

  isItemRepeat(item: Message | History, itemList: Message[] | History[], i: number): boolean {
    if (i === 0) return false; // first item can't be repeat
    return item.user.id === itemList[i-1].user.id;
  }

  isItemTimeDiff(item: Message | History, itemList: Message[] | History[], i: number, difference: number) {
    if (i === itemList.length - 1) return true; // last item always shows time
    if (item.user.id !== itemList[i+1].user.id) return true; // always show for last of user
    const field = item['sentTime'] ? 'sentTime' : 'changeTime';
    if (itemList[i+1][field] - item[field] > difference) return true; //show if the time diff is big enough
  }


  startMessageRefresh(): void {
    if (!this.messagesRefresh && this.activeTab == 'messages-tab') {
      this.messagesRefresh = setTimeout(() => this.getMessages(), 10000);
    }
  }

  stopMessagesRefresh(): void {
    if (this.messagesRefresh) {
      clearTimeout(this.messagesRefresh);
      this.messagesRefresh = null;
    }
  }

  startHistoryRefresh(): void {
    if (!this.historyRefresh && this.activeTab == 'history-tab') {
      this.historyRefresh = setTimeout(() => this.getHistory(), 10000);
    }
  }

  stopHistoryRefresh(): void {
    if (this.historyRefresh) {
      clearTimeout(this.historyRefresh);
      this.historyRefresh = null;
    }
  }

  fillMessage(message: Message) {
    const e = document.getElementById(`message-${message.id}`);
    if (e) e.innerHTML = message.body;
  }

}
