import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { DatePipe } from '@angular/common';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { DashboardComponent } from './dashboard';
import { HeaderComponent } from './header';
import { FooterComponent } from './footer';
import { LoginComponent } from './login';
import { AboutComponent } from './about';
import { SignupComponent } from './signup';
import { ControlMessagesComponent } from './control-messages';
import { ValidationService } from './_services';
import { UserComponent } from './user';
import { TicketComponent } from './ticket';
import { CaptchaComponent } from './captcha';
import { AdminComponent } from './admin';
import { AlertModule } from './_alert';


@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    HeaderComponent,
    FooterComponent,
    LoginComponent,
    AboutComponent,
    SignupComponent,
    ControlMessagesComponent,
    UserComponent,
    TicketComponent,
    CaptchaComponent,
    AdminComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
    NgbModule,
    AlertModule
  ],
  providers: [
    ValidationService,
    DatePipe
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
