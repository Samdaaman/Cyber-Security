export interface User {
  id: number;
  username: string;
  isAdmin: number;
}
