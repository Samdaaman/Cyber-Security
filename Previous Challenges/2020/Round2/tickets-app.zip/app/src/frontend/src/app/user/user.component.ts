import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { FormGroup, FormControl, Validators, FormBuilder }  from '@angular/forms';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { filter, first } from 'rxjs/operators';
import { Subscription } from 'rxjs';
import { DomSanitizer } from '@angular/platform-browser';


import { ApiService, AuthenticationService } from '@app/_services';
import { User, Image } from '@app/_models';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  editing: boolean = false;
  user: User = {id: -1, username: '', isAdmin: 0};

  image: Image = {blob: null, filename: null, src: null};
  selectedImage: Image = {blob: null, filename: null, src: null};
  userForm: FormGroup;
  canEdit: boolean = false;
  loading = {
    user: false,
    image: false,
    savingUser: false,
    savingImage: false
  };
  submitted = false;
  error = '';

  private userSubscription: Subscription;
  private userFormSubscription: Subscription;

  constructor(
    private formBuilder: FormBuilder,
    private activatedRoute: ActivatedRoute,
    private router: Router,
    public authenticationService: AuthenticationService,
    public apiService: ApiService,
    private sanitizer: DomSanitizer,
    private changeDetector: ChangeDetectorRef
  ) { }

  ngOnInit(): void {

    this.userForm = this.formBuilder.group({
            username: ['', Validators.required],
            image: ['']
        });


    this.getUser();
    this.userSubscription = this.router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event: NavigationEnd) => {
      this.getUser();
    });

    this.userFormSubscription = this.userForm.valueChanges.subscribe((updatedValue) => {
      Object.assign(this.user, updatedValue);
    });

  }

  ngOnDestroy(): void {
    this.userSubscription.unsubscribe();
    this.userFormSubscription.unsubscribe();
  }

  getUser(): void {
    this.loading.user = true;
    const id = +this.activatedRoute.snapshot.paramMap.get('id');
    this.apiService.getUser(id)
      .subscribe((user) => {
        this.user = user;
        this.loading.user = false;
        this.userForm.controls.username.setValue(user.username);
        const currentUser = this.authenticationService.currentUserValue;
        this.canEdit = (this.user.id === currentUser.id) || !!currentUser.isAdmin;
        this.getImage();
      },
      error => {
        this.loading.user = false;
      }
    );
  }

  getImage(): void {
    this.loading.image = true;
    this.apiService.getImage(this.user)
      .subscribe(
        data => {
          this.loading.image = false;
          this.image = data;
          this.selectedImage = this.image;
        },
        error => {
          this.loading.image = false;
        }
      )
  }

  processImage(event): void {
    if (event.target.files && event.target.files.length) {
      const [file] = event.target.files;
      event.target.labels[0].innerHTML = file.name;
      const reader = new FileReader();

      reader.addEventListener('load', (event: any) => {
        this.selectedImage = {
          blob: event.target.result.split(',')[1],
          filename: file.name,
          src: event.target.result
        };
      });
      reader.readAsDataURL(file);
    }
  }

  saveImage(): void {
    if (this.selectedImage.blob === this.image.blob) return;

    this.loading.savingImage = true;

    this.apiService.addImage(this.selectedImage, this.user)
      .subscribe(
        data => {
          this.image = this.selectedImage;
          this.loading.savingImage = false;
        },
        error => {
          this.loading.savingImage = false;
        }
      )
  }

  get form() { return this.userForm.controls; }


  toggleEdit(): void {
    this.editing = !this.editing;
  }

  saveUser(): void {
    this.submitted = true;

    if (this.userForm.invalid) return;

    this.saveImage();

    this.user.username = this.userForm.controls.username.value;

    this.loading.savingUser = true;
    this.apiService.updateUser(this.user)
      .pipe(first())
      .subscribe(
        data => {
          this.authenticationService.refresh().subscribe();
          this.loading.savingUser = false;
          this.error = '';
          this.toggleEdit();
        },
        error => {
          this.error = error.error.message;
          this.loading.savingUser = false;
        }
      )
  }

}
