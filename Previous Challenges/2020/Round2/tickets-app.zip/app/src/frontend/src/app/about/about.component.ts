import { Component, OnInit } from '@angular/core';
import { first } from 'rxjs/operators';

import { PatchNotesService } from '@app/_services';
import { PatchNote } from '@app/_models';

@Component({
  selector: 'app-about',
  templateUrl: './about.component.html',
  styleUrls: ['./about.component.css']
})
export class AboutComponent implements OnInit {

  patchNotes: PatchNote[];
  updater;

  constructor(
    private patchNotesService: PatchNotesService
  ) { }

  ngOnInit(): void {

    this.patchNotesService.patchNotes.subscribe((patchNotes) => {
      this.patchNotes = patchNotes;
    });

    this.loadPatchNotes();
    this.updater = setInterval(() => this.loadPatchNotes(), 10000)

  }

  loadPatchNotes() {
    this.patchNotesService.loadPatchNotes()
      .subscribe();
  }

  fillPatchNote(patchNote: PatchNote) {
    const e = document.getElementById(`patch-${patchNote.id}`);
    if (e) e.innerHTML = `${patchNote.version}: ${patchNote.body}`;
  }

  ngOnDestroy(): void {
    clearInterval(this.updater);
  }

}
