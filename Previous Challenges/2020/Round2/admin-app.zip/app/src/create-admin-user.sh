#!/bin/bash

function rand() {
  local len="${1}"
  dd if=/dev/urandom bs=1 count=$((len / 2)) 2>/dev/null | xxd -p
}

USERNAME="${1}"
OUTFILE="${2}"
SECRET_NAME="${3}"
REGION="${4}"
shift
if [ -z "${OUTFILE}" -o -z "${SECRET_NAME}" -o -z "${REGION}" ] ; then
  echo "Usage: ${BASH_SOURCE[0]} <username> <outfile> <secret name> <region>" >&2
  exit 1
fi

if grep -q "^${USERNAME}:" "${OUTFILE}" ; then
  echo "User already created"
  exit 0
elif grep -q "^${USERNAME}:" "${OUTFILE}".bak ; then
  echo "User already created, copying from backup file"
  grep "^${USERNAME}:" "${OUTFILE}".bak >> "${OUTFILE}"
  exit 0
fi

password=$(rand 7)
pwd_hash=$(echo -n "${password}" | md5sum | awk '{print $1}')
echo "${USERNAME}:${pwd_hash}:admin" >> "${OUTFILE}"
aws --region "${REGION}" secretsmanager put-secret-value --secret-id "${SECRET_NAME}" --secret-string "${password}"
