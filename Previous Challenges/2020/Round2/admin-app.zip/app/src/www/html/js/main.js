var api_prefix = '/api';
var debug = true;
const poll_interval = 5000;
var evtSource = null;
var poll_timer = null;

var columns = {
  "tickets": {
    "title": {
      "name": "Ticket title",
      "len": 45
    },
    "status": {
      "name": "Status",
      "len": null
    },
  },
  "messages": {
    "body": {
      "name": "Message subject",
      "len": 75
    },
    "author": {
      "name": "Author",
      "len": 20
    },
    "sentTime": {
      "name": "Date",
      "len": null
    },
  },
};

function debugLog(msg) {
  if (debug) { console.log(msg); }
}

function parseJwt(token) {
  try {
    return JSON.parse(atob(token.split(".")[1]));
  } catch (e) {
    return null;
  }
}

function currTimestamp() {
  return Math.floor(+ new Date() / 1000);
}

function jwtHasExpired(token) {
  var parsed = parseJwt(token);
  if (! parsed || ! parsed["exp"]) { return true; }
  return parsed["exp"] <= currTimestamp();
}

function textTruncate(str, length, ending) {
  if (str === undefined || str === null) {
    return "";
  }
  if (length === undefined || length === null || str.length <= length) {
    return str;
  }
  if (ending === undefined || ending === null) {
    ending = "...";
  }
  return str.substring(0, length - ending.length) + ending;
};

function resetTable(name) {
  $("#" + name + " table > thead").empty()
  var tr = $("<tr/>").appendTo("#" + name + " table > thead");
  $.each(columns[name], function (key, props) {
    var str = textTruncate(props["name"], props["len"]);
    $("<th/>").html(str).appendTo(tr);
  });
  $("#" + name + " table > tbody").empty()
}

function addRow(name, all_obj, data, callback) {
  var tr = $("<tr/>").appendTo("#" + name + " table > tbody").data(data);
  tr.click(callback);
  $.each(columns[name], function (key, props) {
    var str = textTruncate(all_obj[key], props["len"]);
    var td = $("<td/>").appendTo(tr);
    $("<span/>").html(str).appendTo(td);
  });
}

function getCurrentTicket() {
  return sessionStorage.getItem("selected_ticket");
}

function setCurrentTicket(ticketId) {
  return sessionStorage.setItem("selected_ticket", ticketId);
}

function openTicket(evt, ticketId) {
  var tr;
  if (evt != null) {
    tr = $(this);
  } else {
    $("#tickets table > tbody > tr").each(function (i, this_tr) {
      if ($(this_tr).data("ticketId") == ticketId) { tr = $(this_tr); }
    });
  }
  var ticket;
  if (! ticketId && tr) {
    ticketId = tr.data("ticketId");
  }
  if (ticketId) {
    ticket = getTicket(ticketId);
  }
  if (! ticket) { return; }
  debugLog("Opening ticket " + ticketId);
  resetTable("messages");
  $.each(ticket["messages"], function (i, message) {
      addRow("messages", message,
        { "ticketId": ticketId, "messageId": message["id"] },
        showMessagePopup);
    });
  $("#tickets .selected").removeClass("selected");
  tr.addClass("selected");
  setCurrentTicket(ticketId);
}

function getTickets() {
  try {
    var tickets = JSON.parse(localStorage.getItem("latest_data"));
  } catch (e) {
    debugLog("Cannot parse latest_data, clearing local storage");
    localStorage.removeItem("latest_data");
    return;
  }
  $.each(tickets, function (i, ticket) {
    ticket["history"].sort(function (a, b) {
      return a["id"] < b["id"];
    });
    ticket["status"] = ticket["history"][0]["status"];
  });
  return tickets;
}

function getTicket(ticketId) {
  var tickets = getTickets();
  for (let i = 0; i < tickets.length; i++) {
    if (tickets[i]["id"] == ticketId) {
      return tickets[i];
    }
  }
}

function getMessage(ticketId, messageId) {
  var ticket = getTicket(ticketId);
  var messages = ticket["messages"];
  for (let i = 0; i < messages.length; i++) {
    if (messages[i]["id"] == messageId) {
      return messages[i];
    }
  }
}

function rerender() {
  var tickets = getTickets();
  resetTable("tickets");
  $.each(tickets, function (i, ticket) {
    addRow("tickets", ticket,
      { "ticketId": ticket["id"] },
      openTicket);
  });
  $("#tickets table > tbody > tr").each(
    function (i, tr) {
      var ticketId = $(tr).data("ticketId");
      var btn_label;
      var btn_action;
      if ($(tr).find("td:last span").text() == "open" ) {
        btn_label = "CLOSE";
        btn_action = showCloseTicketPopup;
      } else {
        btn_label = "DELETE";
        btn_action = showDeleteTicketPopup;
      }
      var button = $("<button/>").appendTo($(tr)
        .children("td:last")).text(btn_label);
      button.click(function (evt) {
        btn_action(ticketId);
        evt.stopPropagation();
      })
    });
  resetTable("messages");
  openTicket(null, getCurrentTicket()); 
}

function showErrorPopup() {
  debugLog("Error: " + JSON.stringify(arguments));
  var prefix = "";
  var error;
  if (arguments.length >= 3) {
    let xhr = arguments[0];
    if (xhr.status == 0 || xhr.status == 401 || xhr.status == 500) {
      return;
    }
    error = xhr.responseJSON["error"];
    timeout = arguments[3];
    // prefix += "Error [" + xhr.status + "]: ";
  } else {
    error = arguments[0];
    timeout = arguments[1];
  }
  if (error) {
    showAlertPopup(prefix + error, false, timeout);
  }
}

function showAlertPopup(message, ok) {
  $("#alert-popup h2").html(message);
  $("#alert-popup").addClass("fade-in");
  $("#alert-popup").removeClass("fade-out");
  if (! ok) {
    $("#alert-popup").addClass("bad");
  }
  $("#alert-popup").on("click", null, hideAlertPopup);
  $("#alert-popup").show();
  setTimeout(hideAlertPopup, 2500);
}

function hideAlertPopup() {
  $("#alert-popup h2").html();
  $("#alert-popup").addClass("fade-out");
  $("#alert-popup").removeClass("fade-in");
  $("#alert-popup").off("click", null, hideAlertPopup);
  setTimeout(function () {
    $("#alert-popup").hide();
    $("#alert-popup").removeClass("bad");
  }, 1000);
}

function showCloseTicketPopup(ticketId) {
  showChangeTicketPopup(ticketId, "close", closeTicket);
}

function showDeleteTicketPopup(ticketId) {
  showChangeTicketPopup(ticketId, "delete", deleteTicket);
}

function showChangeTicketPopup(ticketId, label, action) {
  function doit() {
    action(ticketId);
    cancel();
  }
  function cancel() {
    hideChangeTicketPopup();
    $("#change-ticket-popup button[name=action]")
      .off("click", null, doit);
  }
  $("#change-ticket-popup h2")
    .text("Are you sure you want to " + label.toLowerCase() + " this ticket?");
  $("#change-ticket-popup button[name=action]")
    .text(label.toUpperCase())
    .on("click", null, doit);
  $("#change-ticket-popup button.cancel").on("click", null, cancel);
  $("#change-ticket-popup").show();
}

function hideChangeTicketPopup() {
  $("#change-ticket-popup").hide();
}

function showMessagePopup(evt) {
  function validate() {
    debugLog("Validating message " + messageId);
    isMessagePhishy(links);
  }
  function reply() {
    showReplyPopup(ticketId, messageId);
    cancel();
  }
  function cancel() {
    hideMessagePopup();
    $("#message-popup button[name=reply]").off("click", null, reply);
    $("#message-popup button[name=validate]").off("click", null, validate);
  }
  var tr = $(this);
  var ticketId = tr.data("ticketId");
  var messageId = tr.data("messageId");
  var message = getMessage(ticketId, messageId);
  var links = Array.from(
    message["body"].matchAll(/https?:\/\/([^\/ ]+)/g),
    m => m[1]);
  debugLog("Opening message (" + ticketId + ") " + messageId);
  $("#messages .selected").removeClass("selected");
  tr.addClass("selected");
  $("#message-popup button[name=reply]").on("click", null, reply);
  $("#message-popup button[name=validate]").on("click", null, validate);
  if (links.length > 0) {
    $("#message-popup button[name=validate]").show();
    $("#message-popup button[name=reply]").removeClass("wide");
  } else {
    $("#message-popup button[name=validate]").hide();
    $("#message-popup button[name=reply]").addClass("wide");
  }
  $("#message-popup button.cancel").on("click", null, cancel);
  $("#message-popup h2").hide();
  $("#message-popup p").html(textTruncate(message["body"]))
  $("#reply-popup").data("ticketId", ticketId);
  $("#reply-popup").data("messageId", messageId);
  $("#message-popup").show();
}

function hideMessagePopup() {
  $("#message-popup").hide();
  $("#message-popup h2").html();
  $("#message-popup p").html()
}

function prepareReplyPopup(url) {
  function send(evt) {
    sendMessage(url);
    cancel();
    evt.preventDefault();
  }
  function cancel() {
    hideReplyPopup();
    $("#reply-popup form").off("submit", null, send);
  }
  $("#reply-popup form").on("submit", null, send);
  $("#reply-popup button.cancel").on("click", null, cancel);
}

function showNewTicketPopup() {
  prepareReplyPopup("/ticket");
  $("#reply-popup button[type=submit]").text("Create ticket");
  $("#reply-popup").show();
  $("#reply-popup input:first").focus();
}

function showReplyPopup(ticketId, messageId) {
  prepareReplyPopup("/ticket/" + ticketId + "/message");
  $("#reply-popup button[type=submit]").text("Reply");
  $("#reply-popup input[name=title]").prop("required", false);
  $("#reply-popup input[name=title]").hide();
  $("#reply-popup").show();
  $("#reply-popup input:first").focus();
}

function hideReplyPopup() {
  $("#reply-popup").hide();
  $("#reply-popup input[name=title]").show();
  $("#reply-popup input[name=title]").val("");
  $("#reply-popup input[name=title]").prop("required", true);
  $("#reply-popup textarea[name=body]").val("");
}

function showLoginPopup(callback) {
  var res = new $.Deferred();
  function action(evt) {
    debugLog("Logging in");
    login(evt)
      .done(function (data, code, xhr) {
        res.resolve(data, code, xhr);
      });
    $("#login-popup form").off("submit", null, action);
  }
  $("#login-popup form").on("submit", null, action);
  $("#login-popup").show();
  $("#login-popup input:first").focus();
  return res;
}

function hideLoginPopup() {
  $("#login-popup").hide();
  $("#login-msg").text("Login to the admin portal");
  $("#login-popup input[name=username]").val("");
  $("#login-popup input[name=password]").val("");
}

function getMe(method, url, data, options, _no_refresh) {
  if (options === undefined) { options = {}; }
  var retry = options["retry"];
  if (retry === undefined) { retry = true; }
  var auth = options["auth"];
  if (auth === undefined) { auth = true; }
  var auth_err_msg = options["auth_err_msg"] || "You are not an admin";
  var headers = options["headers"] || {};
  if (auth) {
    debugLog(url + " is authenticated");
    var access_token = localStorage.getItem("access_token");
    if (! access_token || jwtHasExpired(access_token)) {
      if (_no_refresh) {
         // this shouldn't happen
        debugLog("WTF");
        var xhr = new XMLHttpRequest();
        xhr.open(method, url)
        return new $.Deferred(xhr, null, "unknown").reject();
      }
      debugLog("Refreshing session");
      return refreshSession()
        .then(function () {
          return getMe(method, url, data, options, true);
        });
    }
    headers["Authorization"] = "Bearer " + access_token;
  }
  debugLog("Sending request for " + url);
  if (data) { data = JSON.stringify(data) }
  return $.ajax({
      type: method,
      url: api_prefix + url,
      contentType: "application/json; charset=utf-8",
      dataType: "json",
      headers: headers,
      data: data,
      timeout: 5000})
    .done(function (data, code, xhr) {
      debugLog("OK: " + xhr.status);
      $("#error").empty();
    })
    .catch(function (xhr, code, err) {
      if (xhr.status == 401) {
        debugLog("Error: " + auth_err_msg);
        $("#login-msg").text(auth_err_msg);
        $("#error").empty();
        if (auth && retry) {
          debugLog("Resending " + url);
          return showLoginPopup().then(function () {
            return getMe(method, url, data, options, true);
          });
        } else {
          return showLoginPopup();
        }
      }
      if (xhr.status == 0 || xhr.status >= 500) {
        $("#error").text("Cannot connect to the server");
      }
      var err_msg = err;
      if (xhr.responseJSON && xhr.responseJSON["error"]) {
        err_msg = xhr.responseJSON["error"];
      }
      throw err_msg;
    });
}

function refreshSession() {
  var refresh_token = localStorage.getItem("refresh_token");
  localStorage.removeItem("access_token");
  localStorage.removeItem("refresh_token");
  debugLog("Got refresh token " + refresh_token);
  if (!refresh_token) {
    debugLog("No refresh token");
    return showLoginPopup();
  }
  return getMe("POST", "/authtoken", { "refresh_token": refresh_token },
      { "auth": false, "auth_err_msg": "Session expired" })
    .then(function (data, code, xhr) {
      if (data["refresh_token"]) {
        debugLog("Updating refresh token");
        localStorage.setItem("refresh_token", data["refresh_token"]);
      }
      localStorage.setItem("access_token", data["access_token"]);
      return new $.Deferred().resolve(data, code, xhr);
    });
}

function isMessagePhishy(links) {
  return getMe("POST", "/validate", Object.assign({}, links))
    .done(function (data, code, xhr) {
      if (data["error"]) {
        showErrorPopup(data["error"]);
      }
      else if (data["result"] == "false") {
        showAlertPopup("Smells bad, don't eat it", false);
      }
      else {
        showAlertPopup("All good, do you want chips with it?", true);
      }
    })
    .fail(showErrorPopup);
}

function closeTicket(ticketId) {
  return getMe("PUT", "/ticket/" + ticketId + "/status",
      {"status": "closed"})
    .done(function () { poll(true); })
    .fail(showErrorPopup);
}

function deleteTicket(ticketId) {
  return getMe("DELETE", "/ticket/" + ticketId)
    .done(function () { poll(true); })
    .fail(showErrorPopup);
}

function sendMessage(url) {
  return getMe("PUT", url,
    { "title": $("#reply-popup input[name=title]").val(),
      "body": $("#reply-popup textarea[name=body]").val() })
    .done(function () { poll(true); })
    .fail(showErrorPopup);
}

function poll(once) {
  var headers = {}
  var latest_tag = localStorage.getItem("latest_tag");
  if (latest_tag) {
    headers["If-None-Match"] = latest_tag;
  }
  return getMe("GET", "/tickets", null, { "headers": headers })
    .then(function (data, code, xhr) {
      if (xhr.status == 200) {
        localStorage.setItem("latest_tag", xhr.getResponseHeader("ETag"));
        localStorage.setItem("latest_data", JSON.stringify(data));
        rerender();
      }
      return new $.Deferred().resolve(data, code, xhr);
    })
    .always(function () {
      if (!once) { poll_timer = setTimeout(poll, poll_interval); }
    });
}

function login(evt) {
  if (evt) { evt.preventDefault(); }
  return getMe("POST", "/login",
      { "username": $("#login-popup input[name=username]").val(),
        "password": $("#login-popup input[name=password]").val() },
      { "auth": false, "auth_err_msg": "Wrong username or password" })
    .then(function (data, code, xhr) {
      debugLog("Saving new access and refresh tokens");
      localStorage.setItem("refresh_token", data["refresh_token"]);
      localStorage.setItem("access_token", data["access_token"]);
      hideLoginPopup();
      return new $.Deferred().resolve(data, code, xhr);
    });
}

function logout(evt) {
  if (evt) { evt.preventDefault(); }
  return getMe("POST", "/logout",
      { "refresh_token": localStorage.getItem("refresh_token") },
      { "auth": false })
    .then(function () {
      localStorage.clear();
      if (evtSource !== null) { evtSource.close(); }
      rerender();
      clearTimeout(poll_timer);
      poll();
    });
}

function waitForTickets() {
  var access_token = localStorage.getItem("access_token");
  if (access_token === null || jwtHasExpired(access_token)) {
      return refreshSession().then(waitForTickets);
  }
  evtSource = new EventSourcePolyfill(
    api_prefix + "/waitfor/tickets", {
      "headers": { "Authorization": "Bearer " + access_token }
    });
  evtSource.addEventListener("message", function(evt) {
    if (evt.data) {
      localStorage.setItem("latest_data", evt.data);
      debugLog("Got new tickets");
      $("#error").empty();
      rerender();
    } else {
      debugLog('Still alive');
    }
  });
  evtSource.addEventListener("error", function(xhr, code, err) {
    if (xhr.status == 401) {
      $("#error").text("You are not an admin");
    } else {
      $("#error").text("Cannot connect to the server");
      evtSource.close();
      // retry
      setTimeout(waitForTickets, 5000);
    }
  });
}

$(document).ready(function () {
  api_prefix = document.location.pathname.replace(/\/[^\/]*$/, "") + api_prefix;
  $("#new-ticket").click(showNewTicketPopup);
  $("#logout").click(logout);
  rerender();
  // waitForTickets();
  poll();
});

$(window).on('beforeunload', function(){
  if (evtSource !== null) { evtSource.close(); }
});
