const
  express = require('express'),
  router = express.Router();
  admin = require('../../controllers/admin');


module.exports = () => {
  /**
   * Gets the patch notes
   */
  router.get('/patchnotes', admin.getPatchNotes);

  /**
   * Create a patch note
   */
  router.post('/patchnotes', admin.addPatchNote);

  /**
   * Run a sql query
   */
  router.post('/sqlbox', admin.sqlBox);

  /**
   * Run some python
   */
  router.post('/pythonbox', admin.pythonBox);

  return router;
}
