const
  express = require('express'),
  router = express.Router(),
  admin = require('./api/admin'),
  users = require('./api/users'),
  tickets = require('./api/tickets');


module.exports = () => {
  // Add path for various admin functions
  router.use('/admin', admin());
  // Add path for users
  router.use('/users', users());
  // Add path for tickets
  router.use('/tickets', tickets());

  return router;
}
