const
  express = require('express'),
  router = express.Router(),
  users = require('../../controllers/users');


module.exports = () => {
  /**
   * Gets a list of all users
   */
  router.get('/', users.getAllUsers);

  /**
   * Adds a new user
   */
  router.post('/', users.addUser);

  /**
   * Gets the current users profile
   */
  router.get('/profile', users.getProfile);

  /**
   * Logs in the current user
   */
  router.post('/login', users.login);

  /**
   * Logs out the current user
   */
  router.post('/logout', users.logout);

  /**
   * Upload a profile image
   */
  router.post('/image', users.addUserImage);

  /**
   * Upload a profile image
   */
  router.post('/image/:id', users.addUserImage);

  /**
   * Gets the current users profile image
   */
  router.get('/image', users.getUserImage);

  /**
   * Gets the requested image
   */
  router.get('/image/:id', users.getUserImage);

  /**
   * Gets information for a single user
   */
  router.get('/:userId', users.getUser);

  /**
   * Update the info for a single user
   */
  router.put('/:userId', users.updateUser);

  /**
   * Delete a single user
   */
  router.delete('/:userId', users.deleteUser);


  return router;
}
