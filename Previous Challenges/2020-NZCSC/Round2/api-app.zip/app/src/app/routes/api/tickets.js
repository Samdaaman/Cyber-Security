const
  express = require('express'),
  router = express.Router();
  tickets = require('../../controllers/tickets');


module.exports = () => {
  /**
   * Gets a list of all tickets the current user
   */
  router.get('/', tickets.getTickets);

  /**
   * Create a new ticket
   */
  router.post('/', tickets.addTicket);

  /**
   * Gets information for a single ticket
   */
  router.get('/:ticketId', tickets.getTicket);

  /**
   * Modify a ticket
   */
  router.put('/:ticketId', tickets.updateTicket);

  /**
   * Deletes a single ticket
   */
  router.delete('/:ticketId', tickets.deleteTicket);

  /**
   * Gets all events for a single ticket
   */
  router.get('/:ticketId/events', tickets.getEvents);

  /**
   * Create an event for a single ticket
   */
  router.post('/:ticketId/events', tickets.addEvent);

  /**
   * Gets information for a single ticket event
   */
  router.get('/:ticketId/events/:eventId', tickets.getEvent);

  /**
   * Update a single ticket event
   */
  router.put('/:ticketId/events/:eventId', tickets.updateEvent);

  /**
   * Delete a single ticket event
   */
  router.delete('/:ticketId/events/:eventId', tickets.deleteEvent);

  /**
   * Gets all messages for a single ticket
   */
  router.get('/:ticketId/messages', tickets.getMessages);

  /**
   * Create a message for a single ticket
   */
  router.post('/:ticketId/messages', tickets.addMessage);

  /**
   * Gets information for a single ticket message
   */
  router.get('/:ticketId/messages/:messageId', tickets.getMessage);

  /**
   * Update a single ticket message
   */
  router.put('/:ticketId/messages/:messageId', tickets.updateMessage);

  /**
   * Delete a single ticket message
   */
  router.delete('/:ticketId/messages/:messageId', tickets.deleteMessage);

  return router;
}
