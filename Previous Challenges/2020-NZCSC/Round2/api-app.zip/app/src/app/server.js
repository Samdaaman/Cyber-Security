const
  express = require('express'),
  bodyParser = require('body-parser'),
  cookieParser = require('cookie-parser'),
  useragent = require('express-useragent'),
  cors = require('cors'),
  path = require('path'),
  http = require('http'),
  app = express();

const
  api = require('./routes/api'),
  responses = require('./lib/responses'),
  logger = require('./lib/logger'),
  captcha = require('./lib/captcha'),
  config = require('./config/config'),
  auth = require('./lib/auth');

// Insert request middlware for simple response sending
app.use(responses);

// Express middleware for cookies
app.use(cookieParser());

// Express middleware for user agent
app.use(useragent.express());

// Express middleware for body data
app.use(bodyParser.json({limit: '50mb'}), bodyParser.text(), bodyParser.urlencoded({extended: true}), (req, res, next) => {
  if (typeof req.body === 'string' && req.body.length > 0) { // attempt to mangle request data into json
    req.body = JSON.parse(req.body);
  }
  next();
});

// Enable CORS
app.use(cors({credentials: true, origin: true}));
app.options('*', cors()); // enable pre-flight for other verbs

// Enable authentication middleware
app.use(auth.auth);

// Enable captcha
app.use(captcha());

// api path
app.use('/api', api());

// catch all 404 error
app.all('*', (req, res, next) => {
  if (res.headersSent) return next();
  res.sendNotFound(`Cannot ${req.method} ${req.path}`);
});

// default error handler
app.use(function (err, req, res, next) {
  if (res.headersSent) return next(err);
  res.sendError(err.stack ? err.stack : err);
});

// Enable request logging
app.use(logger.logger());
app.use(logger.logger('err'));

// Set port from config
app.set('port', config.get('port'));
app.set('trust proxy', true);

const server = http.createServer(app);

server.listen(config.get('port'), config.get('hostname'), () => {
  logger.log(`Listening on ${config.get('hostname')}:${config.get('port')}`);
})
