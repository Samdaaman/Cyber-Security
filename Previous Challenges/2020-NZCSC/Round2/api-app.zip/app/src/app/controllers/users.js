const
  md5 = require("md5"),
  fs = require("fs").promises,
  fsConstants = require("fs").constants,
  path = require("path");

const
  auth = require("../lib/auth"),
  utils = require("../lib/utils"),
  logger = require("../lib/logger"),
  pool = require("../lib/db").pool,
  User = require("../models/user"),
  Image = require("../models/image");

function logout(req, res, next) {
  res.clearCookie("authorization");
  res.sendSuccess();
}

function login(req, res, next) {
  pool.query(`SELECT * FROM users JOIN auth ON users.id = auth.id WHERE username = "${req.body.username}"`)
    .then(([rows, fields]) => {
      if (rows.length == 0) throw `User "${req.body.username}" not found.`;
      if (rows.length > 1) throw `Multiple matching users found.`;
      if (md5(req.body.password) != rows[0].hash) throw "Incorrect password.";
      let token = auth.encrypt(rows[0].id);
      let cookieOptions = { maxAge: 2592000000, path: '/api' };
      res.cookie("authorization", token, cookieOptions);
      res.sendSuccess(rows[0]);
    })
    .catch(next);
}

function addUser(req, res, next) {
  function LoginException(message) {
    this.message = message;
    this.name = "LoginException";
  }

  const user = User.fromObject({
    username: req.body.username,
    hash: req.body.password ? md5(req.body.password) : null,
    isAdmin: req.body.isAdmin ? 1 : 0
  });
  if (!user.isValid()) throw new LoginException("Invalid user object.");

  pool.query(`SELECT * FROM users WHERE username = "${user.username}"`)
    .then(([rows, fields]) => {
      if (rows.length > 0) throw new LoginException("Username already in use.");
    })
    .then(() => pool.query(`INSERT INTO users (username, isAdmin) VALUES ("${user.username}", ${user.isAdmin});`))
    .then(([rows, fields]) => pool.query(`INSERT INTO auth (id, hash) VALUES (${rows.insertId}, "${user.hash}");`))
    .then(() => pool.query(`SELECT * FROM users JOIN auth ON users.id = auth.id WHERE username = "${req.body.username}"`))
    .then(([rows, fields]) => {
      res.sendSuccess(rows);
    })
    .catch((err) => {
      if (err.name == "LoginException") return res.sendBadRequest(err.message);
      next(err);
    })
};

function getUser(req, res, next) {
  if (!utils.authCheck(req.user)) return res.sendNotAuthorized();
  pool.query(`SELECT id, username, isAdmin FROM users WHERE id = "${req.params.userId}"`)
    .then(([rows, fields]) => {
      if (rows.length === 0) return res.sendNotFound("User not found.");
      const user = User.fromObject(rows[0]);
      res.sendSuccess(rows[0]);
    })
    .catch(next);
}

function getUsers(req, res, next) {
  if (!utils.authCheck(req.user)) return res.sendNotAuthorized();
  pool.query(`SELECT id, username, isAdmin FROM users;`)
    .then(([rows, fields]) => {
      const users = rows.map(item => User.fromObject(item));
      res.sendSuccess(users);
    })
    .catch(next);
}

function updateUser(req, res, next) {
  if (!utils.authCheck(req.user)) return res.sendNotAuthorized();
  const user = User.fromObject({
    username: req.body.username,
    isAdmin: req.body.isAdmin ? 1 : 0
  });
  pool.query(`UPDATE users SET username = "${user.username}", isAdmin = "${user.isAdmin}" WHERE id = "${req.params.userId}";`)
    .then(([rows, fields]) => {
      res.sendSuccess({id: req.params.userId});
    })
    .catch(next);
};

function deleteUser(req, res, next) {
  if (!utils.authCheck(req.user)) return res.sendNotAuthorized();
  pool.query(`DELETE FROM users WHERE id = "${req.params.userId}";`)
    .then(([rows, fields]) => {
      if (rows.affectedRows !== 1) return res.sendNotFound("User not found.");
      res.sendSuccess();
    })
    .catch(next);
};


function getProfile(req, res, next) {
  if (!utils.authCheck(req.user)) return res.sendNotAuthorized();
  res.sendSuccess(req.user);
};

async function addUserImage(req, res, next) {
  if (!utils.authCheck(req.user)) return res.sendNotAuthorized();
  let image;
  try {
    image = new Image(req.body.filename, req.body.blob);
  } catch (e) {
    return res.sendBadRequest(e.message);
  }
  if (!image.isValid()) return res.sendBadRequest("Invalid Image");

  const userId = req.params.id ? req.params.id : req.user.id;

  attachImageQuery = {
    update: `UPDATE images SET filename = "${image.b64fname}" WHERE id = "${userId}";`,
    insert: `INSERT INTO images (id, filename) VALUES ("${userId}", "${image.b64fname}");`
  }

  fs.writeFile(image.filename, image.blob, 'base64')
    .then(() => pool.query(`SELECT filename FROM images WHERE id = "${userId}";`))
    .then(async ([rows, fields]) => {
      if (rows.length !== 0) {
        attachImageQuery = attachImageQuery.update;
        const storedName = utils.b64Dec(rows[0].filename);
        if (rows[0].filename !== image.b64fname &&
            await fs.access(storedName, fsConstants.F_OK | fsConstants.W_OK).then(() => true).catch(() => false)) await fs.unlink(storedName).catch(next);
      } else {
        attachImageQuery = attachImageQuery.insert;
      }
    })
    .then(() => pool.query(attachImageQuery))
    .then(([rows, fields]) => {
      res.sendSuccess({id: image.b64fname});
    })
    .catch(next);
}

async function getUserImage(req, res, next) {
  if (!utils.authCheck(req.user)) return res.sendNotAuthorized();
  let filename;
  if (req.params.id) {
    if (req.params.id.match(/^\d+$/)) {
      filename = await pool.query(`SELECT filename FROM images WHERE id = "${req.params.id}";`).then(([rows, fields]) => {if (!rows.length) throw "User does not have an image."; return utils.b64Dec(rows[0].filename)}).catch(next);
      if (!filename) return;
    } else {
      try {
        filename = path.resolve(path.join("./app/images/", utils.b64Dec(req.params.id)));
      } catch (e) {
        return next(e);
      }
    }
  } else {
    filename = await pool.query(`SELECT filename FROM images WHERE id = "${req.user.id}";`).then(([rows, fields]) => {if (!rows.length) throw "User does not have an image."; return utils.b64Dec(rows[0].filename)}).catch(next);
    if (!filename) return;
  }
  if (filename.startsWith('/etc')) return res.sendBadRequest(`Illegal access attempted: ${filename}`);
  fs.access(filename, fsConstants.F_OK | fsConstants.R_OK)
    .catch((err) => {
      throw err.code === 'ENOENT' ? `File '${filename}' does not exist.` : `Cannot read file '${filename}': permission denied.`;
    })
    .then(() => fs.readFile(filename, 'base64'))
    .then((data) => {
      res.sendSuccess({filename, blob: data});
    })
    .catch(next);
}

module.exports = {
  getAllUsers: getUsers,
  addUser: addUser,
  getProfile: getProfile,
  login: login,
  logout: logout,
  getUser: getUser,
  updateUser: updateUser,
  deleteUser: deleteUser,
  addUserImage: addUserImage,
  getUserImage: getUserImage
}
