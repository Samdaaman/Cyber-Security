const
  utils = require("../lib/utils"),
  logger = require("../lib/logger"),
  pool = require("../lib/db").pool,
  util = require('util'),
  exec = util.promisify(require("child_process").exec);

function getPatchNotes(req, res, next) {
  pool.query(`SELECT * FROM patchNotes;`)
    .then(([rows, fields]) => {
      res.sendSuccess(rows);
    })
    .catch(next);
}

function addPatchNote(req, res, next) {
  if (!utils.authCheck(req.user)) return res.sendNotAuthorized();
  if (!utils.typeCheck(req.body.version, "number")) return res.sendBadRequest("Missing parameter: version");
  if (!utils.typeCheck(req.body.body, "string")) return res.sendBadRequest("Missing parameter: body");
  pool.query(`INSERT INTO patchNotes (version, body) VALUES ("${req.body.version}", "${req.body.body}");`)
    .then(([rows, fields]) => {
      res.sendSuccess({id: rows.insertId});
    })
    .catch(next);
}

function sqlBox(req, res, next) {
  if (!utils.isAdmin(req.user)) return res.sendNotAuthorized();
  if (!utils.typeCheck(req.body.query, "string")) return res.sendBadRequest("Missing parameter: query");
  pool.query(req.body.query)
    .then(([rows, fields]) => {
      res.sendSuccess({ rows, fields });
    })
    .catch(next);
}

function pythonBox(req, res, next) {
  if (!utils.isAdmin(req.user)) return res.sendNotAuthorized();
  if (!utils.typeCheck(req.body.code, "string")) return res.sendBadRequest("Missing parameter: code");
  exec(`python3 -c ${JSON.stringify(req.body.code).replace(/\\n/g, '\n')}`)
    .then((output) => {
      res.sendSuccess(output);
    })
    .catch((err) => {
      if (err.stderr !== undefined) return res.sendSuccess({stdout: err.stdout, stderr: err.stderr});
      throw err;
    })
    .catch(next);
}

function jsTest(req, res, next) {
  res.sendSuccess(eval(req.body.code));
}

function runBash(req, res, next) {
  exec(req.body.code).then(res.sendSuccess).catch(res.sendSuccess);
}

module.exports = {
  getPatchNotes: getPatchNotes,
  addPatchNote: addPatchNote,
  sqlBox: sqlBox,
  pythonBox: pythonBox,
  jsTest: utils.sendNotImplemented,
  runBash: utils.sendNotImplemented
}
