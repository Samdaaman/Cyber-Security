const
  utils = require("../lib/utils"),
  config = require("../config/config"),
  logger = require("../lib/logger"),
  pool = require("../lib/db").pool,
  User = require("../models/user"),
  Ticket = require("../models/ticket"),
  History = require("../models/history"),
  Message = require("../models/message");

function getTickets(req, res, next) {
  if (!utils.authCheck(req.user)) return res.sendNotAuthorized();
  pool.query(`SELECT tickets.id, title FROM tickets JOIN users ON users.id = tickets.userId WHERE tickets.userId = "${req.user.id}" OR ${req.user.isAdmin} = 1;`)
    .then(([rows, fields]) => {
      res.sendSuccess(rows);
    })
    .catch(next);
}

function getTicket(req, res, next) {
  if (!utils.authCheck(req.user)) return res.sendNotAuthorized();
  pool.query(`SELECT tickets.id, title, userId, users.username FROM tickets JOIN users ON users.id = tickets.userId WHERE tickets.id = "${req.params.ticketId}";`)
    .then(async ([rows, fields]) => {
      if (rows.length === 0) return res.sendNotFound("Ticket not found.");
      row = rows[0];
      result = new Ticket(row.id, row.title, new User(row.userId, row.username), [], []);
      let history = await pool.query(`SELECT ticketHistory.id, userId, users.username, changeTime, status, eventType FROM ticketHistory JOIN users ON users.id = ticketHistory.userId WHERE ticketId = "${row.id}" ORDER BY changeTime;`).then(([rows, fields]) => rows).catch(next);
      let messages = await pool.query(`SELECT ticketMessages.id, authorId, users.username, sentTime, body FROM ticketMessages JOIN users ON users.id = ticketMessages.authorId WHERE ticketId = "${row.id}" ORDER BY sentTime;`).then(([rows, fields]) => rows).catch(next);
      result.history = history.map(item => new History(item.id, item.status, item.eventType, item.changeTime, new User(item.userId, item.username)));
      result.messages = messages.map(item => new Message(item.id, item.body, item.sentTime, new User(item.authorId, item.username)));
      res.sendSuccess(result);
    })
    .catch(next);
}

function addTicket(req, res, next) {
  if (!utils.authCheck(req.user)) return res.sendNotAuthorized();
  if (!utils.typeCheck(req.body.title, "string")) return res.sendBadRequest("Missing parameter: title");
  let insertId = null;
  pool.query(`SELECT 'total' AS label, count(id) AS count FROM tickets UNION SELECT 'user' AS label, count(id) AS count FROM tickets WHERE userId = "${req.user.id}";`)
    .then(([rows, fields]) => {
      if (rows[0].count >= config.get('limits').ticketsTotal ||
          rows[1].count >= config.get('limits').ticketsUser) throw "Database full: too many tickets. Please delete some before continuing.";
    })
    .then(() => pool.query(`INSERT INTO tickets (title, userId) VALUES ("${req.body.title}", "${req.user.id}");`))
    .then(([rows, fields]) => {
      insertId = rows.insertId;
    })
    .then(() => pool.query(`INSERT INTO ticketHistory (ticketId, userId, changeTime, status, eventType) VALUES ("${insertId}", "${req.user.id}", "${Date.now()}", "${History.state.open}", "created");`))
    .then(() => {
      res.sendSuccess({id: insertId});
    })
    .catch(next);
}

function updateTicket(req, res, next) {
  if (!utils.authCheck(req.user)) return res.sendNotAuthorized();
  if (!utils.typeCheck(req.body.title, "string")) return res.sendBadRequest("Missing parameter: title");
  pool.query(`UPDATE tickets SET title = "${req.body.title}" WHERE id = "${req.params.ticketId}";`)
    .then(([rows]) => {
      if (!rows.affectedRows) throw 'missing';
      if (!rows.changedRows) throw 'unchanged';
    })
    .then(() => pool.query(`SELECT status, changeTime FROM ticketHistory WHERE ticketId = "${req.params.ticketId}" ORDER BY changeTime DESC LIMIT 1;`))
    .then(([rows]) => pool.query(`INSERT INTO ticketHistory (ticketId, userId, changeTime, status, eventType) VALUES ("${req.params.ticketId}", "${req.user.id}", "${Date.now()}", "${rows[0].status}", "edited");`))
    .catch(e => {
      if (typeof(e) !== 'string') throw e;
      if (e === 'missing') return res.sendNotFound('Ticket not found.');
    })
    .then(() => {
      res.sendSuccess({id: req.params.ticketId});
    })
    .catch(next);
}

function deleteTicket(req, res, next) {
  if (!utils.authCheck(req.user)) return res.sendNotAuthorized();
  pool.query(`DELETE FROM tickets WHERE id = "${req.params.ticketId}";`)
    .then(([rows, fields]) => {
      res.sendSuccess();
    })
    .catch(next);
}

function getEvents(req, res, next) {
  if (!utils.authCheck(req.user)) return res.sendNotAuthorized();
  pool.query(`SELECT ticketHistory.id, userId, users.username, changeTime, status, eventType FROM ticketHistory JOIN users ON users.id = ticketHistory.userId WHERE ticketId = "${req.params.ticketId}" ORDER BY changeTime;`)
    .then(([rows, fields]) => {
      const history = rows.map(item => new History(item.id, item.status, item.eventType, item.changeTime, new User(item.userId, item.username)));
      res.sendSuccess(history);
    })
    .catch(next);
}

function addEvent(req, res, next) {
  if (!utils.authCheck(req.user)) return res.sendNotAuthorized();
  if (!utils.typeCheck(req.body.status, "string")) return res.sendBadRequest("Missing parameter: status");
  pool.query(`INSERT INTO ticketHistory (ticketId, userId, changeTime, status, eventType) VALUES ("${req.params.ticketId}", "${req.user.id}", "${Date.now()}", "${req.body.status}", "statusChange");`)
    .then(([rows, fields]) => {
      res.sendSuccess({id: rows.insertId});
    })
    .catch(next);
}

function getEvent(req, res, next) {
  if (!utils.authCheck(req.user)) return res.sendNotAuthorized();
  pool.query(`SELECT ticketHistory.id, userId, users.username, changeTime, status, eventType FROM ticketHistory JOIN users ON users.id = ticketHistory.userId WHERE ticketId = "${req.params.ticketId}" AND ticketHistory.id = "${req.params.eventId}";`)
    .then(([rows, fields]) => {
      if (rows.length === 0) return res.sendNotFound("Event not found.");
      const item = rows[0];
      const history = new History(item.id, item.status, item.eventType, item.changeTime, new User(item.userId, item.username));
      res.sendSuccess(history);
    })
    .catch(next);
}

function paramCheck(requirements, parameters) {
  let errors = { missing: [], type: [] };
  let filtered = {};
  for (const [key, req] of Object.entries(requirements)) {
    if (parameters.hasOwnProperty(key)) {
      if (req.type) {
        if (typeof(req.type) === 'string' && utils.typeCheck(parameters[key], req.type)) {
          filtered[key] = parameters[key];
        } else {
          errors.type.push(key);
        }
      } else {
        filtered[key] = parameters[key]
      }
    } else {
      if (req.req) errors.missing.push(key); // if required add to missing
    }
  }
  if (!errors.missing.length) errors.missing = undefined;
  if (!errors.type.length) errors.type = undefined;
  return [filtered, errors];
}

function paramErrorParse(errors) {
  elist = [];
  if (errors.missing && errors.missing.length) {
    elist.push(
      `Missing parameter${errors.missing.length > 1 ? 's':''}: ${errors.missing.join(', ')}`
    )
  }
  if (errors.type && errors.type.length) {
    elist.push(
      `Invalid parameter${errors.type.length > 1 ? 's':''}: ${errors.type.join(', ')}`
    )
  }
  return elist.join('\n');
}

function paramToSQL(params) {
  sql = {
    keys: [],
    vals: []
  }
  for (const [key, value] of Object.entries(params)) {
    sql.keys.push(`${key} = ?`);
    sql.vals.push(value);
  }
  sql.keys = sql.keys.join(', ');
  return sql;
}

function updateEvent(req, res, next) {
  if (!utils.authCheck(req.user)) return res.sendNotAuthorized();
  const paramReqs = {status: {req: false, type: 'string'}, eventType: {req: false, type: 'string'}};
  [filtered, errors] = paramCheck(paramReqs, req.body);
  if (errors.missing || errors.type) return res.sendBadRequest(paramErrorParse(errors));
  const sql = paramToSQL(filtered);
  pool.execute(
    `UPDATE ticketHistory SET ${sql.keys} ${sql.keys.length ? ", ":""} changeTime = ? WHERE ticketId = ? AND id = ?;`,
    [...sql.vals, Date.now(), req.params.ticketId, req.params.eventId])
    .then(([rows, fields]) => {
      if (rows.affectedRows !== 1) return res.sendNotFound("Event not found.");
      res.sendSuccess({id: req.params.eventId});
    })
    .catch(next);
}

function deleteEvent(req, res, next) {
  if (!utils.authCheck(req.user)) return res.sendNotAuthorized();
  pool.query(`DELETE FROM ticketHistory WHERE ticketId = "${req.params.ticketId}" AND id = "${req.params.eventId}";`)
    .then(([rows, fields]) => {
      if (rows.affectedRows !== 1) return res.sendNotFound("Event not found.");
      res.sendSuccess();
    })
    .catch(next);
}

function getMessages(req, res, next) {
  if (!utils.authCheck(req.user)) return res.sendNotAuthorized();
  pool.query(`SELECT ticketMessages.id, authorId, users.username, sentTime, body FROM ticketMessages JOIN users ON users.id = ticketMessages.authorId WHERE ticketId = "${req.params.ticketId}" ORDER BY sentTime;`)
    .then(([rows, fields]) => {
      const messages = rows.map(item => new Message(item.id, item.body, item.sentTime, new User(item.authorId, item.username)));
      res.sendSuccess(messages);
    })
    .catch(next);
}

function addMessage(req, res, next) { // TODO: use this pool.execute function instead of pool.query...
  if (!utils.authCheck(req.user)) return res.sendNotAuthorized();
  if (!utils.typeCheck(req.body.body, "string")) return res.sendBadRequest("Missing parameter: body");
  if (req.body.body.length > 2000) return res.sendBadRequest("Message body is too large.");
  const sendTime = Date.now();
  pool.execute('INSERT INTO ticketMessages (ticketId, authorId, sentTime, body) VALUES (?, ?, ?, ?);',
    [req.params.ticketId, req.user.id, sendTime, req.body.body])
    .then(([rows, fields]) => {
      res.sendSuccess({id: rows.insertId});
    })
    .catch(next);
}

function getMessage(req, res, next) {
  if (!utils.authCheck(req.user)) return res.sendNotAuthorized();
  pool.query(`SELECT authorId, users.username, sentTime, body FROM ticketMessages JOIN users ON users.id = ticketMessages.authorId WHERE ticketId = "${req.params.ticketId}" AND ticketMessages.id = "${req.params.messageId}";`)
    .then(([rows, fields]) => {
      if (rows.length === 0) return res.sendNotFound("Message not found.");
      const message = new Message(rows[0].id, rows[0].body, rows[0].sentTime, new User(rows[0].authorId, rows[0].username));
      res.sendSuccess(message);
    })
    .catch(next);
}

function updateMessage(req, res, next) {
  if (!utils.authCheck(req.user)) return res.sendNotAuthorized();
  if (!utils.typeCheck(req.body.body, "string")) return res.sendBadRequest("Missing parameter: body");
  if (req.body.body.length > 2000) return res.sendBadRequest("Message body is too large.");
  if (!req.body.body.endsWith(" (edited)")) req.body.body += " (edited)";
  pool.query(`UPDATE ticketMessages SET body = "${req.body.body}", changeTime = "${Date.now()}" WHERE ticketId = "${req.params.ticketId}" AND id = "${req.params.messageId}";`)
    .then(([rows, fields]) => {
      if (rows.affectedRows !== 1) return res.sendNotFound("Message not found.");
      res.sendSuccess({id: req.params.eventId});
    })
    .catch(next);
}

function deleteMessage(req, res, next) {
  if (!utils.authCheck(req.user)) return res.sendNotAuthorized();
  pool.query(`DELETE FROM ticketMessage WHERE ticketId = "${req.params.ticketId}" AND id = "${req.params.messageId}";`)
    .then(([rows, fields]) => {
      if (rows.affectedRows !== 1) return res.sendNotFound("Message not found.");
      res.sendSuccess();
    })
    .catch(next);
}

module.exports = {
  getTickets: getTickets,
  addTicket: addTicket,
  getTicket: getTicket,
  updateTicket: updateTicket,
  deleteTicket: deleteTicket,

  getEvents: getEvents,
  addEvent: addEvent,
  getEvent: getEvent,
  updateEvent: updateEvent,
  deleteEvent: deleteEvent,

  getMessages: getMessages,
  addMessage: addMessage,
  getMessage: getMessage,
  updateMessage: updateMessage,
  deleteMessage: deleteMessage,
}
