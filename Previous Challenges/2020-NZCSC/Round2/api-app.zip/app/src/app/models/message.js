class Message {
  constructor(id, body, sentTime, user) {
    this.id = id;
    this.body = body;
    this.sentTime = sentTime;
    this.user = user;
  }
}

module.exports = Message;
