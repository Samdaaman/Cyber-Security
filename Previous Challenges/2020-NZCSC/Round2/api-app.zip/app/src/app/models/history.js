class History {
  constructor(id, status, eventType, changeTime, user) {
    this.id = id;
    this.status = status;
    this.eventType = eventType;
    this.changeTime = changeTime;
    this.user = user;
  }

  static state = {open: "open", closed: "closed"}
}

module.exports = History;
