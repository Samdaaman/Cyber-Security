const utils = require("../lib/utils");

class User {
  constructor(id, username, isAdmin, hash) {
    this.id = id;
    this.username = username;
    this.isAdmin = isAdmin;
    this.hash = hash;
  }

  static fromObject(obj) {
    let user = new User();
    for (const key in obj) {
      if (obj.hasOwnProperty(key) && user.hasOwnProperty(key)) {
        user[key] = obj[key];
      }
    }
    return user;
  }

  isValid() {
    return (
      utils.typeCheck(this.username, "string") &&
      utils.typeCheck(this.hash, "string") &&
      utils.typeCheck(this.isAdmin, "number")
    )
  }
}

module.exports = User;
