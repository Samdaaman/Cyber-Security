const
  path = require("path"),
  utils = require("../lib/utils");

class Image {
  constructor(filename, blob) {
    this.filename = Image.sanitizePath(filename);
    this.b64fname = utils.b64Enc(this.filename);
    this.blob = blob;
  }

  static sanitizePath(filename) {
    if (!filename) return;
    const check = filename.match(/(?<=\.)[^\/.]*(?!.*\/)/g);
    if (!check) throw new Error("Invalid filename");
    if (!['png', 'jpg', 'gif'].includes(check[0])) throw new Error(`Invalid file extension: ${check[0]}`);
    return path.resolve(path.join("./app/images/", filename));
  }

  isValid() {
    return (
      utils.typeCheck(this.filename, "string") &&
      utils.typeCheck(this.blob, "string")
    )
  }
}

module.exports = Image;
