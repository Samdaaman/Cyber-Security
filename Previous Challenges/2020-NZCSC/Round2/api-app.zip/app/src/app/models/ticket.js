class Ticket {
  constructor(id, title, user, history, messages) {
    this.id = id;
    this.title = title;
    this.user = user;
    this.history = history;
    this.messages = messages;
  }
}

module.exports = Ticket;
