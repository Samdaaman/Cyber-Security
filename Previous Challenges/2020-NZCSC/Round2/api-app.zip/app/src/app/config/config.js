"use strict";

const convict = require('convict');

let config = convict({
  env: {
    format: ['production', 'development'],
    default: 'development',
    arg: 'env',
    env: 'NODE_ENV'
  },
  port: {
    format: 'port',
    default: 2566,
    arg: 'port',
    env: 'SERVER_PORT'
  },
  hostname: {
    format: String,
    default: 'localhost',
    arg: 'hostname',
    env: 'SERVER_HOSTNAME'
  },
  logfile: {
    format: String,
    default: './tickets.log',
    arg: 'logfile',
    env: 'SERVER_LOGFILE'
  },
  limits: {
    ticketsTotal: {
      format: Number,
      default: 50
    },
    ticketsUser: {
      format: Number,
      default: 10
    }
  },
  db: {
    host: {
      format: String,
      default: 'localhost',
      arg: 'sql-host',
      env: 'SQL_HOST'
    },
    port: {
      format: 'port',
      default: 3306,
      arg: 'sql-port',
      env: 'SQL_port'
    },
    username: {
      format: String,
      default: 'root',
      arg: 'sql-username',
      env: 'SQL_USERNAME'
    },
    password: {
      format: String,
      default: 'dbpassword',
      arg: 'sql-password',
      env: 'SQL_PASSWORD'
    },
    database: {
      format: String,
      default: 'tickets',
      arg: 'sql-database',
      env: 'SQL_DATABASE'
    }
  }
});


module.exports = config;
